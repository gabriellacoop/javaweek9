class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread state before starting: " + Thread.currentThread().getState());
        try {
            Thread.sleep(9000); // Sleep for 9 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Thread state after sleep: " + Thread.currentThread().getState());
    }
}

public class Exercise3 {
    public static void main(String[] args) {
        Thread thread = new Thread(new MyRunnable());
        System.out.println("Thread state before starting: " + thread.getState());
        thread.start();
        try {
            Thread.sleep(9000); // Sleep for 9 second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Thread state after starting: " + thread.getState());
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Thread state after completion: " + thread.getState());
    }
}
