class MyRunnable implements Runnable {
    public void run() {
        long timestamp = System.currentTimeMillis();
        System.out.println(Thread.currentThread().getName() + ": " + timestamp);
        try {
            Thread.sleep(1000); // Sleep for 1 second to make the difference noticeable
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

public class Exercise4 {
    public static void main(String[] args) {
        System.out.println("Starting threads...");
        for (int i = 0; i < 5; i++) {
            Thread thread = new Thread(new MyRunnable());
            System.out.println("Starting thread: " + thread.getName());
            thread.start();
            try {
                Thread.sleep(100); // Introduce a slight delay between starting each thread
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Threads started.");
    }
}
