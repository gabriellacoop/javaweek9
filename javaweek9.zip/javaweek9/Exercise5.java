class MyRunnable implements Runnable {
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                System.out.println("Running...");
                Thread.sleep(1000); // Sleep for 1 second
            }
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted. Exiting...");
        }
    }
}

public class Exercise5 {
    public static void main(String[] args) {
        Thread thread = new Thread(new MyRunnable());
        thread.start();
        try {
            Thread.sleep(5000); // Sleep for 5 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        thread.interrupt();
    }
}
